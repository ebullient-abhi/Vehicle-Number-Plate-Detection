%Alphabets
A=imread('images/A.bmp');B=imread('images/B.bmp');C=imread('images/C.bmp');
D=imread('images/D.bmp');E=imread('images/E.bmp');F=imread('images/F.bmp');
G=imread('images/G.bmp');H=imread('images/H.bmp');I=imread('images/I.bmp');
J=imread('images/J.bmp');K=imread('images/K.bmp');L=imread('images/L.bmp');
M=imread('images/M.bmp');N=imread('images/N.bmp');O=imread('images/O.bmp');
P=imread('images/P.bmp');Q=imread('images/Q.bmp');R=imread('images/R.bmp');
S=imread('images/S.bmp');T=imread('images/T.bmp');U=imread('images/U.bmp');
V=imread('images/V.bmp');W=imread('images/W.bmp');X=imread('images/X.bmp');
Y=imread('images/Y.bmp');Z=imread('images/Z.bmp');

%Natural Numbers
one=imread('images/1.bmp');two=imread('images/2.bmp');
three=imread('images/3.bmp');four=imread('images/4.bmp');
five=imread('images/5.bmp'); six=imread('images/6.bmp');
seven=imread('images/7.bmp');eight=imread('images/8.bmp');
nine=imread('images/9.bmp'); zero=imread('images/0.bmp');

%Creating Array for Alphabets
letter=[A B C D E F G H I J K L M N O P Q R S T U V W X Y Z];

%Creating Array for Numbers
number=[one two three four five six seven eight nine zero];

NewTemplates=[letter number];
save ('NewTemplates','NewTemplates')
clear all